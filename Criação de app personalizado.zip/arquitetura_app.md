# Arquitetura do Aplicativo Vidraria Dujoca

## Visão Geral da Arquitetura

```
+------------------------------------------+
|                                          |
|             FRONTEND                     |
|  +----------------------------------+    |
|  |                                  |    |
|  |  +-------------+ +-------------+ |    |
|  |  | Área Pública| | Área Privada| |    |
|  |  | - Home      | | - Portal do | |    |
|  |  | - Catálogo  | |   Cliente   | |    |
|  |  | - Orçamentos| | - Portal do | |    |
|  |  | - Contato   | |  Colaborador| |    |
|  |  +-------------+ +-------------+ |    |
|  |                                  |    |
|  +----------------------------------+    |
|                                          |
+------------------+---------------------+
                   |
+------------------v---------------------+
|                                        |
|              BACKEND                   |
|  +--------------------------------+    |
|  |                                |    |
|  |  +------------+ +-----------+  |    |
|  |  | API Routes | | Serviços  |  |    |
|  |  | - Auth     | | - Email   |  |    |
|  |  | - Produtos | | - SMS     |  |    |
|  |  | - Usuários | | - PDF     |  |    |
|  |  | - Pedidos  | | - Storage |  |    |
|  |  +------------+ +-----------+  |    |
|  |                                |    |
|  +--------------------------------+    |
|                                        |
+------------------+---------------------+
                   |
+------------------v---------------------+
|                                        |
|           BANCO DE DADOS               |
|  +--------------------------------+    |
|  |                                |    |
|  |  +-----------+ +------------+  |    |
|  |  | Relacional| | NoSQL      |  |    |
|  |  | - Usuários| | - Logs     |  |    |
|  |  | - Produtos| | - Analytics|  |    |
|  |  | - Pedidos | | - Cache    |  |    |
|  |  +-----------+ +------------+  |    |
|  |                                |    |
|  +--------------------------------+    |
|                                        |
+------------------------------------------+
```

## Estrutura de Componentes

### Frontend (Next.js)

```
src/
├── app/                    # Rotas e páginas da aplicação
│   ├── (public)/           # Área pública
│   │   ├── page.tsx        # Home
│   │   ├── sobre/
│   │   ├── produtos/
│   │   ├── orcamentos/
│   │   ├── projetos/
│   │   ├── blog/
│   │   ├── faq/
│   │   └── contato/
│   ├── cliente/            # Portal do Cliente
│   │   ├── page.tsx        # Dashboard do cliente
│   │   ├── projetos/
│   │   ├── pedidos/
│   │   ├── orcamentos/
│   │   ├── documentos/
│   │   ├── agendamento/
│   │   ├── suporte/
│   │   └── perfil/
│   └── colaborador/        # Portal do Colaborador
│       ├── page.tsx        # Dashboard do colaborador
│       ├── consumiveis/
│       ├── documentos/
│       ├── ferias/
│       ├── manutencao/
│       ├── plano-semanal/
│       ├── producao/
│       ├── comunicacao/
│       └── treinamentos/
├── components/             # Componentes reutilizáveis
│   ├── ui/                 # Componentes de UI básicos
│   ├── layout/             # Componentes de layout
│   ├── forms/              # Componentes de formulários
│   ├── cards/              # Componentes de cards
│   ├── tables/             # Componentes de tabelas
│   └── modals/             # Componentes de modais
├── hooks/                  # Custom hooks
├── lib/                    # Funções utilitárias
├── styles/                 # Estilos globais
└── types/                  # Definições de tipos TypeScript
```

### Backend (Next.js API Routes)

```
src/
├── app/
│   └── api/                # API Routes
│       ├── auth/           # Autenticação
│       ├── produtos/       # Gerenciamento de produtos
│       ├── orcamentos/     # Gerenciamento de orçamentos
│       ├── clientes/       # Gerenciamento de clientes
│       ├── colaboradores/  # Gerenciamento de colaboradores
│       ├── consumiveis/    # Pedidos de consumíveis
│       ├── ferias/         # Gestão de férias
│       ├── manutencao/     # Manutenção de máquinas
│       ├── plano-semanal/  # Plano semanal de obrigações
│       ├── producao/       # Relatórios de produção
│       └── notificacoes/   # Sistema de notificações
└── lib/
    ├── db/                 # Conexão com banco de dados
    ├── auth/               # Lógica de autenticação
    ├── email/              # Serviço de email
    ├── sms/                # Serviço de SMS
    ├── pdf/                # Geração de PDFs
    └── storage/            # Armazenamento de arquivos
```

## Fluxo de Dados

### Autenticação
1. Usuário acessa página de login
2. Insere credenciais
3. Sistema valida credenciais
4. Gera token JWT
5. Redireciona para dashboard apropriado (cliente ou colaborador)

### Solicitação de Orçamento
1. Cliente preenche formulário de orçamento
2. Envia dados e arquivos
3. Sistema registra solicitação no banco de dados
4. Notifica equipe comercial via email
5. Cliente recebe confirmação de recebimento

### Pedido de Consumíveis
1. Colaborador acessa área de pedidos
2. Preenche formulário com itens necessários
3. Sistema registra pedido
4. API envia email para setor de compras
5. Colaborador recebe confirmação de solicitação

### Plano Semanal
1. Sistema gera automaticamente plano semanal toda segunda-feira
2. Colaborador visualiza plano no portal
3. Pode imprimir versão formatada
4. Sistema envia notificação via SMS
5. Colaborador confirma recebimento

## Modelo de Dados

### Usuários
```
User {
  id: UUID
  name: String
  email: String
  password: String (hashed)
  role: Enum (ADMIN, CLIENT, EMPLOYEE)
  department: String (for employees)
  position: String (for employees)
  createdAt: DateTime
  updatedAt: DateTime
}
```

### Produtos
```
Product {
  id: UUID
  name: String
  description: Text
  specifications: JSON
  category: String
  images: String[]
  price: Decimal?
  isActive: Boolean
  createdAt: DateTime
  updatedAt: DateTime
}
```

### Orçamentos
```
Quote {
  id: UUID
  clientId: UUID?
  clientName: String
  clientEmail: String
  clientPhone: String
  description: Text
  attachments: String[]
  status: Enum (PENDING, PROCESSING, COMPLETED, REJECTED)
  totalValue: Decimal?
  validUntil: DateTime?
  createdAt: DateTime
  updatedAt: DateTime
}
```

### Pedidos de Consumíveis
```
SupplyRequest {
  id: UUID
  employeeId: UUID
  items: {
    name: String,
    quantity: Number,
    unit: String,
    urgency: Enum (LOW, MEDIUM, HIGH)
  }[]
  justification: Text?
  status: Enum (PENDING, APPROVED, REJECTED, DELIVERED)
  approvedBy: UUID?
  createdAt: DateTime
  updatedAt: DateTime
}
```

### Férias
```
VacationRequest {
  id: UUID
  employeeId: UUID
  startDate: DateTime
  endDate: DateTime
  status: Enum (PENDING, APPROVED, REJECTED)
  approvedBy: UUID?
  comments: Text?
  createdAt: DateTime
  updatedAt: DateTime
}
```

## Interfaces de Usuário

### Tela Inicial (Pública)
- Header com logo, menu de navegação e botão de login
- Banner principal com imagem de destaque e call-to-action
- Seção de produtos em destaque
- Seção "Por que escolher a Vidraria Dujoca"
- Seção de projetos recentes
- Seção de depoimentos de clientes
- Formulário de contato rápido
- Footer com informações de contato, links úteis e redes sociais

### Dashboard do Cliente
- Header com logo, menu de navegação e perfil do usuário
- Sidebar com links para as diferentes seções
- Cards com resumo de projetos em andamento
- Lista de orçamentos recentes
- Notificações importantes
- Gráfico de histórico de pedidos
- Links rápidos para ações comuns

### Dashboard do Colaborador
- Header com logo, menu de navegação e perfil do usuário
- Sidebar personalizada conforme função
- Cards com tarefas pendentes
- Plano semanal em destaque
- Notificações importantes
- Acesso rápido às ferramentas mais utilizadas
- Indicadores de desempenho relevantes para a função

## Responsividade e Adaptação Mobile

### Breakpoints
- Mobile: 0-640px
- Tablet: 641-1024px
- Desktop: 1025px+

### Estratégias
- Design mobile-first
- Menu hamburguer em telas pequenas
- Reorganização de layouts em colunas para telas menores
- Ajuste de tamanho de fontes e elementos
- Otimização de imagens para diferentes resoluções
- Funcionalidades adaptadas para touch em dispositivos móveis

## Considerações de Segurança
- Autenticação JWT com refresh tokens
- Proteção contra CSRF, XSS e SQL Injection
- Rate limiting para prevenir ataques de força bruta
- Validação de dados em frontend e backend
- Sanitização de inputs
- HTTPS obrigatório
- Logs de auditoria para ações sensíveis
- Backup regular de dados
