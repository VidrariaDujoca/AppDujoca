# Prompt para Desenvolvimento de Aplicativo Web/Mobile para Vidraria Dujoca

## Descrição do Projeto
Desenvolva um aplicativo web completo, expansível para desktop e mobile, pronto para publicação nas lojas Apple e Android, para a Vidraria Dujoca, uma indústria de transformação de vidro. O aplicativo deve ser moderno, responsivo e seguir as melhores práticas de UX/UI do mercado.

## Estrutura Principal
O aplicativo deve ser dividido em três áreas principais, cada uma com acesso e funcionalidades específicas:

### 1. Área Geral (Pública)
* **Home**: Apresentação da empresa, destaques de produtos e serviços
* **Sobre Nós**: História, missão, visão e valores da empresa
* **Produtos e Serviços**: Catálogo completo com imagens, descrições e especificações técnicas
* **Solicitação de Orçamentos**: Formulário intuitivo com campos para detalhamento do projeto e upload de arquivos/desenhos
* **Projetos Realizados**: Galeria de cases de sucesso com imagens e descrições
* **Blog**: Artigos sobre tendências, inovações e dicas sobre vidros
* **FAQ**: Perguntas frequentes organizadas por categorias
* **Contato**: Formulário de contato, mapa de localização, telefones e horários de atendimento
* **Área de Login**: Acesso aos portais do cliente e do colaborador

### 2. Portal do Cliente (Acesso Restrito)
* **Dashboard**: Visão geral das informações e atividades do cliente
* **Meus Projetos**: Acompanhamento em tempo real dos projetos em andamento
* **Histórico de Pedidos**: Visualização de todos os pedidos anteriores com status e detalhes
* **Orçamentos**: Lista de orçamentos solicitados, pendentes e aprovados
* **Documentos**: Acesso a notas fiscais, contratos e certificados
* **Agendamento**: Sistema para marcação de visitas técnicas ou entregas
* **Suporte Técnico**: Canal direto para solicitações de suporte
* **Perfil**: Gerenciamento de informações cadastrais e preferências

### 3. Portal do Colaborador (Acesso Restrito e Individualizado)
* **Dashboard Personalizado**: Informações relevantes conforme função do colaborador
* **Pedido de Consumíveis**: Sistema para solicitação de materiais com:
  - Formulário categorizado por tipo de material
  - Histórico de pedidos
  - Status de aprovação
  - API integrada para envio automático ao e-mail do setor de compras
* **Documentos Pessoais**:
  - Folhas de pagamento em PDF
  - Contracheques
  - Documentos contratuais
* **Gestão de Férias**:
  - Solicitação de férias
  - Visualização do status da solicitação
  - Mapa de férias da equipe com filtros por setor/período
* **Manutenção de Máquinas**:
  - Cronograma de manutenção preventiva
  - Checklist de verificações
  - Registro de manutenções realizadas
  - Alertas de manutenções pendentes
* **Plano Semanal de Obrigações**:
  - Geração automática toda segunda-feira
  - Opção de impressão em formato amigável
  - API para envio de notificações via SMS
  - Confirmação de leitura/recebimento
* **Relatório de Produção** (exclusivo para chefes de turno):
  - Formulário para registro diário de produção
  - Métricas e indicadores de desempenho
  - Comparativos com períodos anteriores
  - Exportação de relatórios em diversos formatos
* **Comunicação Interna**:
  - Sistema de mensagens entre colaboradores
  - Quadro de avisos importantes
  - Notificações personalizáveis
* **Treinamentos**:
  - Calendário de treinamentos disponíveis
  - Materiais de estudo
  - Certificados e histórico de capacitações

## Requisitos Técnicos

### Frontend
* Interface moderna e intuitiva seguindo princípios de Material Design ou similar
* Design totalmente responsivo (mobile-first)
* Animações suaves e feedback visual para interações
* Paleta de cores alinhada com a identidade visual da Vidraria Dujoca
* Componentes reutilizáveis para manter consistência visual
* Suporte a temas claro/escuro
* Otimização de carregamento para conexões lentas

### Backend
* API RESTful segura e bem documentada
* Sistema robusto de autenticação e autorização
* Diferentes níveis de permissão para colaboradores
* Integração com serviços de e-mail e SMS
* Sistema de logs para auditoria e monitoramento
* Backup automático de dados
* Mecanismos de cache para otimização de desempenho

### Segurança
* Autenticação de dois fatores para áreas restritas
* Criptografia de dados sensíveis
* Proteção contra ataques comuns (CSRF, XSS, SQL Injection)
* Sessões seguras com expiração automática
* Política de senhas fortes
* Registro de tentativas de acesso suspeitas

### Integrações
* API para envio de e-mails ao setor de compras
* API para envio de SMS com planos semanais
* Possibilidade de integração futura com sistemas ERP
* Exportação de dados em formatos padrão (CSV, Excel, PDF)

## Tecnologias Recomendadas

### Opção 1: Stack Microsoft Azure
* **Frontend**: React.js com TypeScript
* **UI Framework**: Material UI ou Fluent UI
* **Backend**: ASP.NET Core ou Azure Functions
* **Banco de Dados**: Azure SQL Database
* **Autenticação**: Azure Active Directory B2C
* **Hospedagem**: Azure App Service
* **Mobile**: React Native ou Xamarin para apps nativos

### Opção 2: Stack JavaScript Completa
* **Frontend**: Next.js com TypeScript
* **UI Framework**: Tailwind CSS com componentes personalizados
* **Backend**: Next.js API Routes ou Node.js com Express
* **Banco de Dados**: MongoDB Atlas ou PostgreSQL
* **Autenticação**: NextAuth.js ou Auth0
* **Hospedagem**: Vercel ou Azure App Service
* **Mobile**: React Native com Expo

### Opção 3: Solução Low-Code/No-Code com FlutterFlow
* **Plataforma**: FlutterFlow para desenvolvimento visual
* **Framework**: Flutter para código nativo em iOS e Android
* **Backend**: Firebase para autenticação, banco de dados e hospedagem
* **Extensões**: Código personalizado para integrações específicas
* **Publicação**: Exportação direta para lojas de aplicativos

## Considerações para Implementação
* Priorizar a experiência do usuário em todas as interfaces
* Implementar sistema progressivo de onboarding para novos usuários
* Desenvolver pensando na escalabilidade futura
* Criar documentação detalhada para facilitar manutenção
* Implementar analytics para monitorar uso e identificar melhorias
* Planejar testes com usuários reais antes do lançamento final
* Considerar estratégia de backup e recuperação de dados

## Entregáveis Esperados
* Código-fonte completo do aplicativo
* Documentação técnica e de usuário
* Arquivos de design (wireframes, mockups, protótipos)
* Manual de implantação e configuração
* Guia de manutenção e atualização
* Estratégia de publicação nas lojas de aplicativos

Este prompt serve como base para o desenvolvimento do aplicativo da Vidraria Dujoca, podendo ser adaptado e expandido conforme necessidades específicas identificadas durante o processo de desenvolvimento.
