'use client'

import { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Menu, X, ChevronDown } from 'lucide-react'

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen)
  }

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex-shrink-0">
            <Link href="/" className="flex items-center">
              <span className="text-2xl font-bold text-blue-700">Vidraria Dujoca</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className="text-gray-700 hover:text-blue-600 font-medium">
              Início
            </Link>
            <Link href="/sobre" className="text-gray-700 hover:text-blue-600 font-medium">
              Sobre Nós
            </Link>
            <div className="relative group">
              <button 
                className="text-gray-700 hover:text-blue-600 font-medium flex items-center"
                onClick={toggleDropdown}
              >
                Produtos
                <ChevronDown className="ml-1 h-4 w-4" />
              </button>
              <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden group-hover:block">
                <Link href="/produtos/residenciais" className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50">
                  Residenciais
                </Link>
                <Link href="/produtos/comerciais" className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50">
                  Comerciais
                </Link>
                <Link href="/produtos/especiais" className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50">
                  Projetos Especiais
                </Link>
              </div>
            </div>
            <Link href="/orcamentos" className="text-gray-700 hover:text-blue-600 font-medium">
              Orçamentos
            </Link>
            <Link href="/projetos" className="text-gray-700 hover:text-blue-600 font-medium">
              Projetos
            </Link>
            <Link href="/contato" className="text-gray-700 hover:text-blue-600 font-medium">
              Contato
            </Link>
          </nav>

          {/* Login Button */}
          <div className="hidden md:flex items-center space-x-4">
            <Link 
              href="/login" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md font-medium transition-colors"
            >
              Área Restrita
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={toggleMenu}
              className="text-gray-700 hover:text-blue-600 focus:outline-none"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4">
            <div className="flex flex-col space-y-4">
              <Link 
                href="/" 
                className="text-gray-700 hover:text-blue-600 font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Início
              </Link>
              <Link 
                href="/sobre" 
                className="text-gray-700 hover:text-blue-600 font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Sobre Nós
              </Link>
              <div>
                <button 
                  onClick={toggleDropdown}
                  className="text-gray-700 hover:text-blue-600 font-medium flex items-center"
                >
                  Produtos
                  <ChevronDown className="ml-1 h-4 w-4" />
                </button>
                {isDropdownOpen && (
                  <div className="ml-4 mt-2 space-y-2">
                    <Link 
                      href="/produtos/residenciais" 
                      className="block text-gray-700 hover:text-blue-600"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Residenciais
                    </Link>
                    <Link 
                      href="/produtos/comerciais" 
                      className="block text-gray-700 hover:text-blue-600"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Comerciais
                    </Link>
                    <Link 
                      href="/produtos/especiais" 
                      className="block text-gray-700 hover:text-blue-600"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Projetos Especiais
                    </Link>
                  </div>
                )}
              </div>
              <Link 
                href="/orcamentos" 
                className="text-gray-700 hover:text-blue-600 font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Orçamentos
              </Link>
              <Link 
                href="/projetos" 
                className="text-gray-700 hover:text-blue-600 font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Projetos
              </Link>
              <Link 
                href="/contato" 
                className="text-gray-700 hover:text-blue-600 font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                Contato
              </Link>
              <Link 
                href="/login" 
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md font-medium transition-colors text-center"
                onClick={() => setIsMenuOpen(false)}
              >
                Área Restrita
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}

export default Header
