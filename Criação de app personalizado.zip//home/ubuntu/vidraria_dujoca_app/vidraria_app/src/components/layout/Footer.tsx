import Link from 'next/link'
import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone } from 'lucide-react'

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Sobre a empresa */}
          <div>
            <h3 className="text-xl font-bold mb-4">Vidraria Dujoca</h3>
            <p className="text-gray-300 mb-4">
              Indústria especializada em transformação de vidro, oferecendo soluções inovadoras e de alta qualidade para projetos residenciais e comerciais desde 1995.
            </p>
            <div className="flex space-x-4">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-white">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-white">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-white">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Links rápidos */}
          <div>
            <h3 className="text-xl font-bold mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-300 hover:text-white">
                  Início
                </Link>
              </li>
              <li>
                <Link href="/sobre" className="text-gray-300 hover:text-white">
                  Sobre Nós
                </Link>
              </li>
              <li>
                <Link href="/produtos" className="text-gray-300 hover:text-white">
                  Produtos
                </Link>
              </li>
              <li>
                <Link href="/orcamentos" className="text-gray-300 hover:text-white">
                  Orçamentos
                </Link>
              </li>
              <li>
                <Link href="/projetos" className="text-gray-300 hover:text-white">
                  Projetos
                </Link>
              </li>
              <li>
                <Link href="/contato" className="text-gray-300 hover:text-white">
                  Contato
                </Link>
              </li>
            </ul>
          </div>

          {/* Produtos */}
          <div>
            <h3 className="text-xl font-bold mb-4">Produtos</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/produtos/residenciais" className="text-gray-300 hover:text-white">
                  Vidros Residenciais
                </Link>
              </li>
              <li>
                <Link href="/produtos/comerciais" className="text-gray-300 hover:text-white">
                  Vidros Comerciais
                </Link>
              </li>
              <li>
                <Link href="/produtos/especiais" className="text-gray-300 hover:text-white">
                  Projetos Especiais
                </Link>
              </li>
              <li>
                <Link href="/produtos/temperados" className="text-gray-300 hover:text-white">
                  Vidros Temperados
                </Link>
              </li>
              <li>
                <Link href="/produtos/laminados" className="text-gray-300 hover:text-white">
                  Vidros Laminados
                </Link>
              </li>
              <li>
                <Link href="/produtos/decorativos" className="text-gray-300 hover:text-white">
                  Vidros Decorativos
                </Link>
              </li>
            </ul>
          </div>

          {/* Contato */}
          <div>
            <h3 className="text-xl font-bold mb-4">Contato</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 mr-2 mt-0.5 text-blue-400" />
                <span className="text-gray-300">
                  Av. Industrial, 1000<br />
                  Distrito Industrial<br />
                  São Paulo - SP, 00000-000
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-2 text-blue-400" />
                <span className="text-gray-300">(11) 5555-5555</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-2 text-blue-400" />
                <a href="mailto:contato@vidrariadujoca.com.br" className="text-gray-300 hover:text-white">
                  contato@vidrariadujoca.com.br
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Vidraria Dujoca. Todos os direitos reservados.</p>
          <div className="mt-2 space-x-4">
            <Link href="/privacidade" className="hover:text-white">
              Política de Privacidade
            </Link>
            <Link href="/termos" className="hover:text-white">
              Termos de Uso
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
