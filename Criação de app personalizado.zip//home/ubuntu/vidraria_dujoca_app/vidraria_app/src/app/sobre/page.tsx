'use client'

import Link from 'next/link'
import { Building2, Users, Award, History } from 'lucide-react'

export default function Sobre() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-blue-700 text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900 to-blue-700 opacity-90"></div>
        <div className="container mx-auto px-4 py-16 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Sobre a Vidraria Dujoca
            </h1>
            <p className="text-xl">
              Conheça nossa história, valores e compromisso com a qualidade e inovação no mercado de transformação de vidro.
            </p>
          </div>
        </div>
      </section>

      {/* Quem Somos */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <div className="relative w-full h-80 md:h-96 bg-gray-300 rounded-lg flex items-center justify-center">
                <span className="text-gray-500">Imagem da Empresa</span>
              </div>
            </div>
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-6">Quem Somos</h2>
              <p className="text-gray-700 mb-4">
                A Vidraria Dujoca é uma indústria especializada em transformação de vidro, fundada em 1995 com o objetivo de oferecer soluções inovadoras e de alta qualidade para projetos residenciais e comerciais.
              </p>
              <p className="text-gray-700 mb-4">
                Com mais de 25 anos de experiência no mercado, nos tornamos referência no setor, combinando tecnologia avançada, matéria-prima de qualidade e profissionais altamente qualificados para entregar produtos que atendem às mais exigentes especificações técnicas e estéticas.
              </p>
              <p className="text-gray-700">
                Nossa estrutura moderna e equipamentos de última geração nos permitem oferecer uma ampla gama de produtos, desde vidros temperados e laminados até peças decorativas e projetos especiais, sempre com o compromisso de excelência e satisfação dos nossos clientes.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Missão, Visão e Valores */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Missão, Visão e Valores</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Nossos princípios fundamentais que orientam todas as nossas ações e decisões.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Missão */}
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="text-blue-600 mb-4 flex justify-center">
                <Building2 className="h-16 w-16" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-center">Missão</h3>
              <p className="text-gray-600 text-center">
                Transformar vidro em soluções inovadoras e de alta qualidade, superando as expectativas dos nossos clientes e contribuindo para o desenvolvimento do setor.
              </p>
            </div>
            
            {/* Visão */}
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="text-blue-600 mb-4 flex justify-center">
                <Award className="h-16 w-16" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-center">Visão</h3>
              <p className="text-gray-600 text-center">
                Ser reconhecida como a empresa líder em soluções em vidro no mercado nacional, referência em inovação, qualidade e sustentabilidade.
              </p>
            </div>
            
            {/* Valores */}
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="text-blue-600 mb-4 flex justify-center">
                <Users className="h-16 w-16" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-center">Valores</h3>
              <ul className="text-gray-600 space-y-2">
                <li className="flex items-center justify-center">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
                  Excelência e qualidade
                </li>
                <li className="flex items-center justify-center">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
                  Inovação e criatividade
                </li>
                <li className="flex items-center justify-center">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
                  Ética e transparência
                </li>
                <li className="flex items-center justify-center">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
                  Compromisso com clientes
                </li>
                <li className="flex items-center justify-center">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
                  Responsabilidade socioambiental
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Nossa História */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Nossa História</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Conheça a trajetória da Vidraria Dujoca e como nos tornamos referência no mercado.
            </p>
          </div>
          
          <div className="relative border-l-4 border-blue-600 ml-6 md:ml-0 md:mx-auto md:max-w-3xl pl-8 pb-8">
            {/* Marco 1 */}
            <div className="mb-12 relative">
              <div className="absolute -left-12 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <History className="h-4 w-4 text-white" />
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-2">1995 - Fundação</h3>
                <p className="text-gray-600">
                  A Vidraria Dujoca foi fundada por João Carlos Duarte, com uma pequena estrutura e foco em vidros temperados para residências.
                </p>
              </div>
            </div>
            
            {/* Marco 2 */}
            <div className="mb-12 relative">
              <div className="absolute -left-12 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <History className="h-4 w-4 text-white" />
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-2">2002 - Expansão</h3>
                <p className="text-gray-600">
                  Ampliação da fábrica e aquisição de novos equipamentos, permitindo a diversificação da linha de produtos e atendimento a projetos comerciais.
                </p>
              </div>
            </div>
            
            {/* Marco 3 */}
            <div className="mb-12 relative">
              <div className="absolute -left-12 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <History className="h-4 w-4 text-white" />
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-2">2010 - Modernização</h3>
                <p className="text-gray-600">
                  Investimento em tecnologia de ponta e automação de processos, aumentando a capacidade produtiva e a qualidade dos produtos.
                </p>
              </div>
            </div>
            
            {/* Marco 4 */}
            <div className="relative">
              <div className="absolute -left-12 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <History className="h-4 w-4 text-white" />
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-2">2020 - Presente</h3>
                <p className="text-gray-600">
                  Consolidação como referência no mercado nacional, com foco em inovação, sustentabilidade e excelência em atendimento ao cliente.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Equipe */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Nossa Equipe</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Conheça os profissionais que fazem a Vidraria Dujoca ser referência em qualidade e inovação.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Membro 1 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-64 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Foto do Colaborador</span>
              </div>
              <div className="p-6 text-center">
                <h3 className="text-xl font-bold mb-1">João Carlos Duarte</h3>
                <p className="text-blue-600 mb-4">Fundador e CEO</p>
                <p className="text-gray-600">
                  Mais de 30 anos de experiência no setor de vidros, liderando a empresa com visão inovadora.
                </p>
              </div>
            </div>
            
            {/* Membro 2 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-64 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Foto do Colaborador</span>
              </div>
              <div className="p-6 text-center">
                <h3 className="text-xl font-bold mb-1">Maria Silva</h3>
                <p className="text-blue-600 mb-4">Diretora de Operações</p>
                <p className="text-gray-600">
                  Especialista em processos industriais, responsável pela eficiência e qualidade da produção.
                </p>
              </div>
            </div>
            
            {/* Membro 3 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-64 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Foto do Colaborador</span>
              </div>
              <div className="p-6 text-center">
                <h3 className="text-xl font-bold mb-1">Carlos Mendes</h3>
                <p className="text-blue-600 mb-4">Diretor Comercial</p>
                <p className="text-gray-600">
                  Responsável pelo relacionamento com clientes e desenvolvimento de novos negócios.
                </p>
              </div>
            </div>
            
            {/* Membro 4 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-64 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Foto do Colaborador</span>
              </div>
              <div className="p-6 text-center">
                <h3 className="text-xl font-bold mb-1">Ana Oliveira</h3>
                <p className="text-blue-600 mb-4">Gerente de Projetos</p>
                <p className="text-gray-600">
                  Arquiteta com expertise em projetos especiais e soluções personalizadas em vidro.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
