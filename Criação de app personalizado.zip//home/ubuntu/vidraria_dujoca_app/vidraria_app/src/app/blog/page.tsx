'use client'

import Link from 'next/link'
import { Calendar, Tag, User } from 'lucide-react'

export default function Blog() {
  // Artigos do blog
  const artigos = [
    {
      id: 'tendencias-vidros-2025',
      titulo: 'Tendências em Vidros para 2025',
      resumo: 'Conheça as principais tendências em vidros decorativos e arquitetônicos para o próximo ano.',
      data: '15 de março de 2025',
      autor: 'Ana Oliveira',
      categoria: 'Tendências',
      imagem: '/placeholder-blog.jpg'
    },
    {
      id: 'vidros-sustentaveis',
      titulo: 'Vidros Sustentáveis: O Futuro da Construção',
      resumo: 'Como os vidros de alta performance contribuem para construções mais sustentáveis e eficientes.',
      data: '28 de fevereiro de 2025',
      autor: 'Carlos Mendes',
      categoria: 'Sustentabilidade',
      imagem: '/placeholder-blog.jpg'
    },
    {
      id: 'cuidados-vidros-temperados',
      titulo: 'Cuidados Essenciais com Vidros Temperados',
      resumo: 'Dicas para manter seus vidros temperados sempre em perfeito estado e prolongar sua vida útil.',
      data: '10 de fevereiro de 2025',
      autor: 'Roberto Silva',
      categoria: 'Manutenção',
      imagem: '/placeholder-blog.jpg'
    },
    {
      id: 'vidros-decorativos-ambientes',
      titulo: 'Vidros Decorativos para Transformar Ambientes',
      resumo: 'Ideias criativas para usar vidros decorativos e transformar completamente o visual de sua casa.',
      data: '25 de janeiro de 2025',
      autor: 'Juliana Costa',
      categoria: 'Decoração',
      imagem: '/placeholder-blog.jpg'
    },
    {
      id: 'seguranca-vidros-laminados',
      titulo: 'Segurança com Vidros Laminados',
      resumo: 'Entenda como os vidros laminados podem aumentar a segurança da sua residência ou estabelecimento comercial.',
      data: '12 de janeiro de 2025',
      autor: 'Paulo Martins',
      categoria: 'Segurança',
      imagem: '/placeholder-blog.jpg'
    },
    {
      id: 'inovacoes-industria-vidro',
      titulo: 'Inovações na Indústria do Vidro',
      resumo: 'As mais recentes inovações tecnológicas que estão revolucionando a indústria de transformação de vidro.',
      data: '05 de janeiro de 2025',
      autor: 'João Carlos Duarte',
      categoria: 'Inovação',
      imagem: '/placeholder-blog.jpg'
    }
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-blue-700 text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900 to-blue-700 opacity-90"></div>
        <div className="container mx-auto px-4 py-16 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Blog e Notícias
            </h1>
            <p className="text-xl">
              Fique por dentro das últimas tendências, dicas e novidades sobre o mundo do vidro.
            </p>
          </div>
        </div>
      </section>

      {/* Filtro de Categorias */}
      <section className="py-8 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-4">
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md font-medium transition-colors">
              Todos
            </button>
            <button className="bg-white hover:bg-gray-100 text-gray-700 px-4 py-2 rounded-md font-medium transition-colors">
              Tendências
            </button>
            <button className="bg-white hover:bg-gray-100 text-gray-700 px-4 py-2 rounded-md font-medium transition-colors">
              Sustentabilidade
            </button>
            <button className="bg-white hover:bg-gray-100 text-gray-700 px-4 py-2 rounded-md font-medium transition-colors">
              Manutenção
            </button>
            <button className="bg-white hover:bg-gray-100 text-gray-700 px-4 py-2 rounded-md font-medium transition-colors">
              Decoração
            </button>
            <button className="bg-white hover:bg-gray-100 text-gray-700 px-4 py-2 rounded-md font-medium transition-colors">
              Segurança
            </button>
            <button className="bg-white hover:bg-gray-100 text-gray-700 px-4 py-2 rounded-md font-medium transition-colors">
              Inovação
            </button>
          </div>
        </div>
      </section>

      {/* Artigos do Blog */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {artigos.map((artigo) => (
              <div key={artigo.id} className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
                <div className="h-48 bg-gray-300 flex items-center justify-center">
                  <span className="text-gray-500">Imagem do Artigo</span>
                </div>
                <div className="p-6">
                  <div className="flex items-center text-sm text-gray-500 mb-3">
                    <Tag className="h-4 w-4 mr-1" />
                    <span>{artigo.categoria}</span>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{artigo.titulo}</h3>
                  <p className="text-gray-600 mb-4">
                    {artigo.resumo}
                  </p>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center text-sm text-gray-500">
                      <Calendar className="h-4 w-4 mr-1" />
                      <span>{artigo.data}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-500">
                      <User className="h-4 w-4 mr-1" />
                      <span>{artigo.autor}</span>
                    </div>
                  </div>
                  <div className="mt-4">
                    <Link 
                      href={`/blog/${artigo.id}`} 
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md font-medium text-sm transition-colors inline-block"
                    >
                      Ler artigo completo
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Inscreva-se em nossa Newsletter</h2>
            <p className="text-gray-600 mb-8">
              Receba as últimas novidades, artigos e dicas diretamente em seu e-mail.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
              <input 
                type="email" 
                placeholder="Seu melhor e-mail" 
                className="flex-grow px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md font-medium transition-colors">
                Inscrever-se
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-4">
              Ao se inscrever, você concorda com nossa Política de Privacidade. Você pode cancelar a inscrição a qualquer momento.
            </p>
          </div>
        </div>
      </section>

      {/* Artigos Relacionados */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Conteúdos Relacionados</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Confira outros conteúdos que podem ser do seu interesse.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Conteúdo 1 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-bold mb-2">Guia de Manutenção de Vidros</h3>
              <p className="text-gray-600 text-sm mb-4">
                Download gratuito do nosso guia completo com dicas de limpeza e conservação de diferentes tipos de vidro.
              </p>
              <Link 
                href="/downloads/guia-manutencao" 
                className="text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                Baixar guia
              </Link>
            </div>
            
            {/* Conteúdo 2 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-bold mb-2">Webinar: Vidros Inteligentes</h3>
              <p className="text-gray-600 text-sm mb-4">
                Assista à gravação do nosso webinar sobre as novas tecnologias em vidros inteligentes e suas aplicações.
              </p>
              <Link 
                href="/webinars/vidros-inteligentes" 
                className="text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                Assistir webinar
              </Link>
            </div>
            
            {/* Conteúdo 3 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-bold mb-2">Calculadora de Vidros</h3>
              <p className="text-gray-600 text-sm mb-4">
                Ferramenta online para calcular a espessura ideal de vidro para diferentes aplicações e dimensões.
              </p>
              <Link 
                href="/ferramentas/calculadora" 
                className="text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                Acessar calculadora
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
