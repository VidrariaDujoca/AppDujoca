'use client'

import { useState } from 'react'
import { ChevronDown, ChevronUp } from 'lucide-react'

export default function FAQ() {
  // Estado para controlar quais perguntas estão expandidas
  const [expandedQuestions, setExpandedQuestions] = useState<number[]>([0])

  // Toggle para expandir/recolher perguntas
  const toggleQuestion = (index: number) => {
    if (expandedQuestions.includes(index)) {
      setExpandedQuestions(expandedQuestions.filter(item => item !== index))
    } else {
      setExpandedQuestions([...expandedQuestions, index])
    }
  }

  // Categorias de perguntas
  const categorias = [
    {
      titulo: 'Produtos e Serviços',
      perguntas: [
        {
          pergunta: 'Quais tipos de vidros a Vidraria Dujoca oferece?',
          resposta: 'A Vidraria Dujoca oferece uma ampla gama de produtos em vidro, incluindo vidros temperados, laminados, comuns, jateados, serigrafados, coloridos e espelhos. Trabalhamos com diversas espessuras e acabamentos para atender às necessidades específicas de cada projeto.'
        },
        {
          pergunta: 'Vocês realizam instalação dos produtos?',
          resposta: 'Sim, oferecemos serviço completo de instalação para todos os nossos produtos. Nossa equipe técnica é altamente qualificada e segue rigorosos padrões de segurança e qualidade durante todo o processo de instalação.'
        },
        {
          pergunta: 'Quais são as vantagens do vidro temperado em relação ao vidro comum?',
          resposta: 'O vidro temperado possui resistência mecânica cerca de 5 vezes maior que o vidro comum, suportando melhor impactos e variações térmicas. Além disso, em caso de quebra, fragmenta-se em pequenos pedaços não cortantes, oferecendo maior segurança. É ideal para portas, janelas, divisórias, guarda-corpos e outros elementos estruturais.'
        }
      ]
    },
    {
      titulo: 'Orçamentos e Pedidos',
      perguntas: [
        {
          pergunta: 'Como solicitar um orçamento?',
          resposta: 'Você pode solicitar um orçamento através do formulário em nosso site, por telefone, e-mail ou pessoalmente em nossa loja. Para orçamentos mais precisos, recomendamos fornecer as medidas exatas, especificações do tipo de vidro desejado e, se possível, fotos ou desenhos do projeto.'
        },
        {
          pergunta: 'Qual o prazo para receber um orçamento?',
          resposta: 'Normalmente, enviamos o orçamento em até 48 horas úteis após o recebimento da solicitação. Projetos mais complexos podem demandar um prazo maior para análise técnica detalhada.'
        },
        {
          pergunta: 'É necessário pagar alguma taxa para solicitar orçamento?',
          resposta: 'Não, todos os nossos orçamentos são gratuitos e sem compromisso. Você só paga após aprovar o orçamento e confirmar o pedido.'
        }
      ]
    },
    {
      titulo: 'Prazos e Entregas',
      perguntas: [
        {
          pergunta: 'Qual o prazo de entrega após a aprovação do orçamento?',
          resposta: 'O prazo varia conforme o tipo de produto e volume do pedido. Vidros temperados têm prazo médio de 7 a 15 dias úteis, enquanto projetos especiais podem levar mais tempo. O prazo exato será informado no orçamento e confirmado após a aprovação.'
        },
        {
          pergunta: 'Vocês entregam em outras cidades?',
          resposta: 'Sim, realizamos entregas em toda a região metropolitana de São Paulo e, dependendo do volume do pedido, podemos atender outras localidades. Os custos de frete e prazo de entrega para regiões mais distantes serão informados no orçamento.'
        },
        {
          pergunta: 'É possível acompanhar o status do meu pedido?',
          resposta: 'Sim, após a confirmação do pedido, você receberá atualizações regulares sobre o status de produção e entrega. Além disso, nossos clientes têm acesso ao portal do cliente, onde podem acompanhar todas as etapas do processo em tempo real.'
        }
      ]
    },
    {
      titulo: 'Pagamento e Garantia',
      perguntas: [
        {
          pergunta: 'Quais formas de pagamento são aceitas?',
          resposta: 'Aceitamos diversas formas de pagamento, incluindo dinheiro, PIX, transferência bancária, cartões de débito e crédito (com possibilidade de parcelamento) e boleto bancário. As condições específicas serão detalhadas no orçamento.'
        },
        {
          pergunta: 'Qual a garantia oferecida para os produtos?',
          resposta: 'Oferecemos garantia de 12 meses para defeitos de fabricação em todos os nossos produtos. Para serviços de instalação, a garantia é de 90 dias. Condições específicas podem variar conforme o tipo de produto e serão detalhadas no certificado de garantia entregue junto com o produto.'
        },
        {
          pergunta: 'É necessário pagar algum valor antecipado?',
          resposta: 'Para pedidos personalizados ou de grande volume, solicitamos um sinal de 50% do valor total no momento da aprovação do orçamento, com o restante sendo pago na entrega ou instalação. Para produtos de linha, o pagamento pode ser feito integralmente na entrega.'
        }
      ]
    },
    {
      titulo: 'Manutenção e Cuidados',
      perguntas: [
        {
          pergunta: 'Como devo limpar os vidros temperados?',
          resposta: 'Recomendamos a limpeza com água e detergente neutro, utilizando um pano macio ou jornal amassado. Evite produtos abrasivos, esponjas ásperas ou objetos pontiagudos que possam riscar o vidro. Para acabamento perfeito, seque com um pano de microfibra ou papel toalha.'
        },
        {
          pergunta: 'Os vidros laminados requerem cuidados especiais?',
          resposta: 'Sim, os vidros laminados devem ser limpos com produtos específicos para vidros, evitando álcool, acetona ou produtos à base de amônia, que podem danificar a película interna. Utilize sempre panos macios e evite pressão excessiva nas bordas.'
        },
        {
          pergunta: 'Vocês oferecem serviço de manutenção para produtos já instalados?',
          resposta: 'Sim, oferecemos serviços de manutenção, ajustes e substituição de peças para todos os nossos produtos. Entre em contato com nossa equipe de atendimento para agendar uma visita técnica e obter um orçamento para o serviço necessário.'
        }
      ]
    }
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-blue-700 text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900 to-blue-700 opacity-90"></div>
        <div className="container mx-auto px-4 py-16 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Perguntas Frequentes
            </h1>
            <p className="text-xl">
              Encontre respostas para as dúvidas mais comuns sobre nossos produtos, serviços e processos.
            </p>
          </div>
        </div>
      </section>

      {/* Conteúdo FAQ */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            {categorias.map((categoria, categoriaIndex) => (
              <div key={categoriaIndex} className="mb-12">
                <h2 className="text-2xl font-bold mb-6 text-blue-700">{categoria.titulo}</h2>
                <div className="space-y-4">
                  {categoria.perguntas.map((item, perguntaIndex) => {
                    const questionIndex = categoriaIndex * 10 + perguntaIndex
                    const isExpanded = expandedQuestions.includes(questionIndex)
                    
                    return (
                      <div 
                        key={perguntaIndex} 
                        className="border border-gray-200 rounded-lg overflow-hidden"
                      >
                        <button
                          className={`w-full text-left p-4 flex justify-between items-center font-medium ${isExpanded ? 'bg-blue-50' : 'bg-white'}`}
                          onClick={() => toggleQuestion(questionIndex)}
                        >
                          <span>{item.pergunta}</span>
                          {isExpanded ? (
                            <ChevronUp className="h-5 w-5 text-blue-600" />
                          ) : (
                            <ChevronDown className="h-5 w-5 text-gray-400" />
                          )}
                        </button>
                        {isExpanded && (
                          <div className="p-4 bg-white border-t border-gray-200">
                            <p className="text-gray-600">{item.resposta}</p>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Não encontrou sua pergunta */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold mb-4">Não encontrou o que procurava?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto mb-8">
            Se você não encontrou a resposta para sua dúvida, entre em contato conosco. Nossa equipe terá prazer em ajudá-lo.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="tel:+551155555555" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md font-medium transition-colors"
            >
              (11) 5555-5555
            </a>
            <a 
              href="mailto:contato@vidrariadujoca.com.br" 
              className="bg-white border border-blue-600 text-blue-600 hover:bg-blue-50 px-6 py-3 rounded-md font-medium transition-colors"
            >
              contato@vidrariadujoca.com.br
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
