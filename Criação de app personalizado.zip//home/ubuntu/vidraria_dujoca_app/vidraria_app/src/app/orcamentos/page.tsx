'use client'

import { useState } from 'react'
import { Send, FileUp, CheckCircle } from 'lucide-react'

export default function Orcamentos() {
  const [formStatus, setFormStatus] = useState({
    submitted: false,
    success: false,
    message: ''
  })

  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: '',
    empresa: '',
    tipo: 'residencial',
    descricao: '',
    arquivos: null
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleFileChange = (e) => {
    setFormData(prev => ({
      ...prev,
      arquivos: e.target.files
    }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // Simulação de envio de formulário
    setFormStatus({
      submitted: true,
      success: true,
      message: 'Orçamento solicitado com sucesso! Em breve nossa equipe entrará em contato.'
    })
    
    // Em um ambiente real, aqui seria feita a chamada à API para envio dos dados
    console.log('Dados do formulário:', formData)
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-blue-700 text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900 to-blue-700 opacity-90"></div>
        <div className="container mx-auto px-4 py-16 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Solicite um Orçamento
            </h1>
            <p className="text-xl">
              Preencha o formulário abaixo e nossa equipe entrará em contato para fornecer um orçamento personalizado para seu projeto.
            </p>
          </div>
        </div>
      </section>

      {/* Formulário de Orçamento */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            {formStatus.submitted && formStatus.success ? (
              <div className="bg-green-50 border border-green-200 rounded-lg p-8 text-center">
                <div className="flex justify-center mb-4">
                  <CheckCircle className="h-16 w-16 text-green-500" />
                </div>
                <h2 className="text-2xl font-bold text-green-800 mb-2">Orçamento Solicitado!</h2>
                <p className="text-green-700 mb-6">
                  {formStatus.message}
                </p>
                <button 
                  onClick={() => setFormStatus({ submitted: false, success: false, message: '' })}
                  className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-md font-medium transition-colors"
                >
                  Solicitar Novo Orçamento
                </button>
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-md p-8">
                <h2 className="text-2xl font-bold mb-6">Informações do Projeto</h2>
                
                <form onSubmit={handleSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    {/* Nome */}
                    <div>
                      <label htmlFor="nome" className="block text-sm font-medium text-gray-700 mb-1">
                        Nome Completo *
                      </label>
                      <input
                        type="text"
                        id="nome"
                        name="nome"
                        value={formData.nome}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    
                    {/* Email */}
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        E-mail *
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    
                    {/* Telefone */}
                    <div>
                      <label htmlFor="telefone" className="block text-sm font-medium text-gray-700 mb-1">
                        Telefone *
                      </label>
                      <input
                        type="tel"
                        id="telefone"
                        name="telefone"
                        value={formData.telefone}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    
                    {/* Empresa */}
                    <div>
                      <label htmlFor="empresa" className="block text-sm font-medium text-gray-700 mb-1">
                        Empresa
                      </label>
                      <input
                        type="text"
                        id="empresa"
                        name="empresa"
                        value={formData.empresa}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                  
                  {/* Tipo de Projeto */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Tipo de Projeto *
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="flex items-center">
                        <input
                          type="radio"
                          id="residencial"
                          name="tipo"
                          value="residencial"
                          checked={formData.tipo === 'residencial'}
                          onChange={handleChange}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                        />
                        <label htmlFor="residencial" className="ml-2 text-sm text-gray-700">
                          Residencial
                        </label>
                      </div>
                      <div className="flex items-center">
                        <input
                          type="radio"
                          id="comercial"
                          name="tipo"
                          value="comercial"
                          checked={formData.tipo === 'comercial'}
                          onChange={handleChange}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                        />
                        <label htmlFor="comercial" className="ml-2 text-sm text-gray-700">
                          Comercial
                        </label>
                      </div>
                      <div className="flex items-center">
                        <input
                          type="radio"
                          id="especial"
                          name="tipo"
                          value="especial"
                          checked={formData.tipo === 'especial'}
                          onChange={handleChange}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                        />
                        <label htmlFor="especial" className="ml-2 text-sm text-gray-700">
                          Projeto Especial
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  {/* Descrição */}
                  <div className="mb-6">
                    <label htmlFor="descricao" className="block text-sm font-medium text-gray-700 mb-1">
                      Descrição do Projeto *
                    </label>
                    <textarea
                      id="descricao"
                      name="descricao"
                      value={formData.descricao}
                      onChange={handleChange}
                      rows={5}
                      required
                      placeholder="Descreva seu projeto com o máximo de detalhes possível, incluindo medidas, especificações e requisitos especiais."
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    ></textarea>
                  </div>
                  
                  {/* Upload de Arquivos */}
                  <div className="mb-8">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Anexar Arquivos
                    </label>
                    <div className="border-2 border-dashed border-gray-300 rounded-md p-6 text-center">
                      <div className="flex justify-center mb-2">
                        <FileUp className="h-8 w-8 text-gray-400" />
                      </div>
                      <p className="text-sm text-gray-500 mb-2">
                        Arraste e solte arquivos aqui, ou clique para selecionar
                      </p>
                      <p className="text-xs text-gray-400 mb-4">
                        Formatos aceitos: PDF, JPG, PNG, DWG (máx. 10MB)
                      </p>
                      <input
                        type="file"
                        id="arquivos"
                        name="arquivos"
                        onChange={handleFileChange}
                        multiple
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => document.getElementById('arquivos').click()}
                        className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-md text-sm font-medium transition-colors"
                      >
                        Selecionar Arquivos
                      </button>
                    </div>
                  </div>
                  
                  {/* Botão de Envio */}
                  <div className="text-center">
                    <button
                      type="submit"
                      className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-md font-medium text-lg transition-colors flex items-center justify-center mx-auto"
                    >
                      <Send className="mr-2 h-5 w-5" />
                      Solicitar Orçamento
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Informações Adicionais */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Como Funciona</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Entenda o processo de solicitação e aprovação de orçamentos na Vidraria Dujoca.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Etapa 1 */}
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="font-bold">1</span>
              </div>
              <h3 className="font-bold mb-2">Solicitação</h3>
              <p className="text-gray-600 text-sm">
                Preencha o formulário com todas as informações do seu projeto.
              </p>
            </div>
            
            {/* Etapa 2 */}
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="font-bold">2</span>
              </div>
              <h3 className="font-bold mb-2">Análise</h3>
              <p className="text-gray-600 text-sm">
                Nossa equipe técnica analisa seu projeto e prepara uma proposta personalizada.
              </p>
            </div>
            
            {/* Etapa 3 */}
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="font-bold">3</span>
              </div>
              <h3 className="font-bold mb-2">Proposta</h3>
              <p className="text-gray-600 text-sm">
                Você recebe o orçamento detalhado com valores, prazos e condições.
              </p>
            </div>
            
            {/* Etapa 4 */}
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="font-bold">4</span>
              </div>
              <h3 className="font-bold mb-2">Execução</h3>
              <p className="text-gray-600 text-sm">
                Após aprovação, iniciamos a produção e instalação conforme cronograma.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Perguntas Frequentes</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Tire suas dúvidas sobre o processo de orçamento e contratação.
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto">
            <div className="space-y-6">
              {/* Pergunta 1 */}
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="font-bold mb-2">Quanto tempo leva para receber o orçamento?</h3>
                <p className="text-gray-600">
                  Normalmente, enviamos o orçamento em até 48 horas úteis após o recebimento da solicitação. Projetos mais complexos podem demandar um prazo maior.
                </p>
              </div>
              
              {/* Pergunta 2 */}
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="font-bold mb-2">É necessário fazer visita técnica?</h3>
                <p className="text-gray-600">
                  Dependendo da complexidade do projeto, podemos agendar uma visita técnica para medições precisas e avaliação das condições do local.
                </p>
              </div>
              
              {/* Pergunta 3 */}
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="font-bold mb-2">Quais formas de pagamento são aceitas?</h3>
                <p className="text-gray-600">
                  Aceitamos diversas formas de pagamento, incluindo transferência bancária, cartão de crédito (parcelad<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>