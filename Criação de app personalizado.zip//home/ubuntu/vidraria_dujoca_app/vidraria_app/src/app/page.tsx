'use client'

import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight, CheckCircle, Phone } from 'lucide-react'

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-blue-700 text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900 to-blue-700 opacity-90"></div>
        <div className="container mx-auto px-4 py-20 relative z-10">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Transformando vidro em soluções para seu projeto
              </h1>
              <p className="text-xl mb-8">
                Há mais de 25 anos oferecendo produtos de alta qualidade e inovação para projetos residenciais e comerciais.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link 
                  href="/orcamentos" 
                  className="bg-white text-blue-700 hover:bg-gray-100 px-6 py-3 rounded-md font-medium text-center transition-colors"
                >
                  Solicitar Orçamento
                </Link>
                <Link 
                  href="/produtos" 
                  className="border border-white text-white hover:bg-white hover:text-blue-700 px-6 py-3 rounded-md font-medium text-center transition-colors"
                >
                  Nossos Produtos
                </Link>
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <div className="relative w-full max-w-md h-80 md:h-96">
                {/* Placeholder para imagem - em produção, substituir por imagem real */}
                <div className="absolute inset-0 bg-gray-300 rounded-lg flex items-center justify-center">
                  <span className="text-gray-500">Imagem de Destaque</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Produtos em Destaque */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Produtos em Destaque</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Conheça nossa linha de produtos de alta qualidade, desenvolvidos com tecnologia avançada e design inovador.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Produto 1 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
              <div className="h-48 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Imagem do Produto</span>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Vidros Temperados</h3>
                <p className="text-gray-600 mb-4">
                  Resistência e segurança para diversos ambientes, com opções de espessuras e acabamentos.
                </p>
                <Link 
                  href="/produtos/temperados" 
                  className="text-blue-600 hover:text-blue-800 font-medium flex items-center"
                >
                  Saiba mais <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            </div>
            
            {/* Produto 2 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
              <div className="h-48 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Imagem do Produto</span>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Vidros Laminados</h3>
                <p className="text-gray-600 mb-4">
                  Proteção acústica e contra raios UV, ideal para fachadas e áreas que exigem segurança.
                </p>
                <Link 
                  href="/produtos/laminados" 
                  className="text-blue-600 hover:text-blue-800 font-medium flex items-center"
                >
                  Saiba mais <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            </div>
            
            {/* Produto 3 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
              <div className="h-48 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Imagem do Produto</span>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Vidros Decorativos</h3>
                <p className="text-gray-600 mb-4">
                  Elegância e personalidade para seu ambiente com vidros jateados, serigrafados e coloridos.
                </p>
                <Link 
                  href="/produtos/decorativos" 
                  className="text-blue-600 hover:text-blue-800 font-medium flex items-center"
                >
                  Saiba mais <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Link 
              href="/produtos" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md font-medium transition-colors"
            >
              Ver Todos os Produtos
            </Link>
          </div>
        </div>
      </section>

      {/* Por que escolher a Vidraria Dujoca */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Por que escolher a Vidraria Dujoca?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Somos referência no mercado de transformação de vidro, oferecendo soluções completas para seus projetos.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Diferencial 1 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-blue-600 mb-4">
                <CheckCircle className="h-12 w-12" />
              </div>
              <h3 className="text-xl font-bold mb-2">Qualidade Garantida</h3>
              <p className="text-gray-600">
                Produtos fabricados com matéria-prima de alta qualidade e rigoroso controle de produção.
              </p>
            </div>
            
            {/* Diferencial 2 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-blue-600 mb-4">
                <CheckCircle className="h-12 w-12" />
              </div>
              <h3 className="text-xl font-bold mb-2">Equipe Especializada</h3>
              <p className="text-gray-600">
                Profissionais qualificados e em constante atualização para oferecer o melhor serviço.
              </p>
            </div>
            
            {/* Diferencial 3 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-blue-600 mb-4">
                <CheckCircle className="h-12 w-12" />
              </div>
              <h3 className="text-xl font-bold mb-2">Tecnologia Avançada</h3>
              <p className="text-gray-600">
                Equipamentos modernos e processos inovadores para garantir produtos de excelência.
              </p>
            </div>
            
            {/* Diferencial 4 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-blue-600 mb-4">
                <CheckCircle className="h-12 w-12" />
              </div>
              <h3 className="text-xl font-bold mb-2">Compromisso com Prazos</h3>
              <p className="text-gray-600">
                Entrega pontual e cumprimento rigoroso dos cronogramas estabelecidos.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Projetos Recentes */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Projetos Recentes</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Conheça alguns dos nossos projetos realizados e veja como podemos transformar sua ideia em realidade.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Projeto 1 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-64 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Imagem do Projeto</span>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Fachada Comercial</h3>
                <p className="text-gray-600 mb-4">
                  Projeto de fachada em vidro laminado para edifício comercial no centro de São Paulo.
                </p>
                <Link 
                  href="/projetos/fachada-comercial" 
                  className="text-blue-600 hover:text-blue-800 font-medium"
                >
                  Ver projeto completo
                </Link>
              </div>
            </div>
            
            {/* Projeto 2 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-64 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Imagem do Projeto</span>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Residência de Alto Padrão</h3>
                <p className="text-gray-600 mb-4">
                  Solução completa em vidros temperados e decorativos para residência em condomínio fechado.
                </p>
                <Link 
                  href="/projetos/residencia-alto-padrao" 
                  className="text-blue-600 hover:text-blue-800 font-medium"
                >
                  Ver projeto completo
                </Link>
              </div>
            </div>
            
            {/* Projeto 3 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-64 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Imagem do Projeto</span>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Shopping Center</h3>
                <p className="text-gray-600 mb-4">
                  Fornecimento e instalação de guarda-corpos e divisórias em vidro para shopping center.
                </p>
                <Link 
                  href="/projetos/shopping-center" 
                  className="text-blue-600 hover:text-blue-800 font-medium"
                >
                  Ver projeto completo
                </Link>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Link 
              href="/projetos" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md font-medium transition-colors"
            >
              Ver Todos os Projetos
            </Link>
          </div>
        </div>
      </section>

      {/* CTA - Contato */}
      <section className="py-16 bg-blue-700 text-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="md:w-2/3 mb-8 md:mb-0">
              <h2 className="text-3xl font-bold mb-4">Pronto para transformar seu projeto em realidade?</h2>
              <p className="text-xl">
                Entre em contato conosco e solicite um orçamento sem compromisso.
              </p>
            </div>
            <div className="md:w-1/3 flex justify-center md:justify-end">
              <Link 
                href="/contato" 
                className="bg-white text-blue-700 hover:bg-gray-100 px-8 py-4 rounded-md font-bold text-lg flex items-center"
              >
                <Phone className="mr-2 h-5 w-5" />
                Fale Conosco
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
