'use client'

import Link from 'next/link'
import { ArrowRight } from 'lucide-react'

export default function Projetos() {
  // Projetos da empresa
  const projetos = [
    {
      id: 'fachada-comercial',
      titulo: 'Fachada Comercial',
      cliente: 'Edifício Corporativo',
      local: 'São Paulo, SP',
      descricao: 'Projeto de fachada em vidro laminado para edifício comercial no centro de São Paulo.',
      categoria: 'comercial',
      imagem: '/placeholder-projeto.jpg'
    },
    {
      id: 'residencia-alto-padrao',
      titulo: 'Residência de Alto Padrão',
      cliente: 'Condomínio Fechado',
      local: 'Campinas, SP',
      descricao: 'Solução completa em vidros temperados e decorativos para residência em condomínio fechado.',
      categoria: 'residencial',
      imagem: '/placeholder-projeto.jpg'
    },
    {
      id: 'shopping-center',
      titulo: 'Shopping Center',
      cliente: 'Shopping Plaza',
      local: 'Ribeirão Preto, SP',
      descricao: 'Fornecimento e instalação de guarda-corpos e divisórias em vidro para shopping center.',
      categoria: 'comercial',
      imagem: '/placeholder-projeto.jpg'
    },
    {
      id: 'hotel-boutique',
      titulo: 'Hotel Boutique',
      cliente: 'Hotel Estrela',
      local: 'Campos do Jordão, SP',
      descricao: 'Projeto de boxes de banheiro e divisórias em vidro jateado para hotel boutique.',
      categoria: 'comercial',
      imagem: '/placeholder-projeto.jpg'
    },
    {
      id: 'casa-de-praia',
      titulo: 'Casa de Praia',
      cliente: 'Residencial',
      local: 'Guarujá, SP',
      descricao: 'Instalação de guarda-corpos, portas e janelas em vidro temperado para casa de praia.',
      categoria: 'residencial',
      imagem: '/placeholder-projeto.jpg'
    },
    {
      id: 'escritorio-advocacia',
      titulo: 'Escritório de Advocacia',
      cliente: 'Escritório Jurídico',
      local: 'São Paulo, SP',
      descricao: 'Divisórias em vidro temperado e portas para escritório de advocacia.',
      categoria: 'comercial',
      imagem: '/placeholder-projeto.jpg'
    }
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-blue-700 text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900 to-blue-700 opacity-90"></div>
        <div className="container mx-auto px-4 py-16 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Nossos Projetos
            </h1>
            <p className="text-xl">
              Conheça alguns dos projetos realizados pela Vidraria Dujoca e veja como podemos transformar sua ideia em realidade.
            </p>
          </div>
        </div>
      </section>

      {/* Filtro de Projetos */}
      <section className="py-8 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-4">
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md font-medium transition-colors">
              Todos
            </button>
            <button className="bg-white hover:bg-gray-100 text-gray-700 px-4 py-2 rounded-md font-medium transition-colors">
              Residenciais
            </button>
            <button className="bg-white hover:bg-gray-100 text-gray-700 px-4 py-2 rounded-md font-medium transition-colors">
              Comerciais
            </button>
            <button className="bg-white hover:bg-gray-100 text-gray-700 px-4 py-2 rounded-md font-medium transition-colors">
              Especiais
            </button>
          </div>
        </div>
      </section>

      {/* Galeria de Projetos */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projetos.map((projeto) => (
              <div key={projeto.id} className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
                <div className="h-64 bg-gray-300 flex items-center justify-center">
                  <span className="text-gray-500">Imagem do Projeto</span>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{projeto.titulo}</h3>
                  <div className="flex justify-between text-sm text-gray-500 mb-3">
                    <span>{projeto.cliente}</span>
                    <span>{projeto.local}</span>
                  </div>
                  <p className="text-gray-600 mb-4">
                    {projeto.descricao}
                  </p>
                  <Link 
                    href={`/projetos/${projeto.id}`} 
                    className="text-blue-600 hover:text-blue-800 font-medium flex items-center"
                  >
                    Ver detalhes <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Depoimentos */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">O que nossos clientes dizem</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Confira os depoimentos de clientes que confiaram na Vidraria Dujoca para seus projetos.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Depoimento 1 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gray-300 rounded-full mr-4"></div>
                <div>
                  <h3 className="font-bold">Carlos Mendonça</h3>
                  <p className="text-sm text-gray-500">Arquiteto</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "Trabalho com a Vidraria Dujoca há mais de 5 anos e sempre fico impressionado com a qualidade dos produtos e o profissionalismo da equipe. Recomendo sem hesitar."
              </p>
            </div>
            
            {/* Depoimento 2 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gray-300 rounded-full mr-4"></div>
                <div>
                  <h3 className="font-bold">Ana Paula Silva</h3>
                  <p className="text-sm text-gray-500">Construtora XYZ</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "A parceria com a Vidraria Dujoca tem sido fundamental para o sucesso dos nossos empreendimentos. Produtos de alta qualidade e cumprimento rigoroso dos prazos."
              </p>
            </div>
            
            {/* Depoimento 3 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gray-300 rounded-full mr-4"></div>
                <div>
                  <h3 className="font-bold">Roberto Almeida</h3>
                  <p className="text-sm text-gray-500">Cliente Residencial</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "Fiquei extremamente satisfeito com o resultado da reforma da minha casa. Os vidros temperados instalados pela Vidraria Dujoca transformaram completamente o ambiente."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA - Orçamento */}
      <section className="py-16 bg-blue-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Pronto para iniciar seu projeto?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Entre em contato conosco e solicite um orçamento sem compromisso. Nossa equipe está pronta para transformar sua ideia em realidade.
          </p>
          <Link 
            href="/orcamentos" 
            className="bg-white text-blue-700 hover:bg-gray-100 px-8 py-4 rounded-md font-bold text-lg inline-block"
          >
            Solicitar Orçamento
          </Link>
        </div>
      </section>
    </div>
  )
}
