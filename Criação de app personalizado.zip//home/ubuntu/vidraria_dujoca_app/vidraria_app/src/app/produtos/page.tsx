'use client'

import Link from 'next/link'
import { ArrowRight, Search } from 'lucide-react'

export default function Produtos() {
  // Categorias de produtos
  const categorias = [
    {
      id: 'residenciais',
      nome: 'Vidros Residenciais',
      descricao: 'Soluções em vidro para ambientes residenciais, combinando segurança, estética e funcionalidade.',
      imagem: '/placeholder-produto.jpg'
    },
    {
      id: 'comerciais',
      nome: 'Vidros Comerciais',
      descricao: 'Produtos desenvolvidos para estabelecimentos comerciais, fachadas e ambientes corporativos.',
      imagem: '/placeholder-produto.jpg'
    },
    {
      id: 'temperados',
      nome: 'Vidros Temperados',
      descricao: 'Alta resistência mecânica e térmica, ideal para portas, janelas, divisórias e guarda-corpos.',
      imagem: '/placeholder-produto.jpg'
    },
    {
      id: 'laminados',
      nome: 'Vidros Laminados',
      descricao: 'Segurança e proteção acústica, com camadas de PVB que impedem estilhaçamento em caso de quebra.',
      imagem: '/placeholder-produto.jpg'
    },
    {
      id: 'decorativos',
      nome: 'Vidros Decorativos',
      descricao: 'Opções estéticas para personalização de ambientes, incluindo jateados, serigrafados e coloridos.',
      imagem: '/placeholder-produto.jpg'
    },
    {
      id: 'especiais',
      nome: 'Projetos Especiais',
      descricao: 'Soluções personalizadas para projetos únicos, desenvolvidas conforme especificações técnicas.',
      imagem: '/placeholder-produto.jpg'
    }
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-blue-700 text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900 to-blue-700 opacity-90"></div>
        <div className="container mx-auto px-4 py-16 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Nossos Produtos
            </h1>
            <p className="text-xl">
              Conheça nossa linha completa de produtos em vidro, desenvolvidos com tecnologia avançada e design inovador.
            </p>
          </div>
        </div>
      </section>

      {/* Filtro de Produtos */}
      <section className="py-8 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="bg-white p-4 rounded-lg shadow-md">
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="relative flex-grow">
                <input 
                  type="text" 
                  placeholder="Buscar produtos..." 
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 pl-10"
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
              <div className="w-full md:w-auto">
                <select className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option value="">Todas as categorias</option>
                  <option value="residenciais">Residenciais</option>
                  <option value="comerciais">Comerciais</option>
                  <option value="temperados">Temperados</option>
                  <option value="laminados">Laminados</option>
                  <option value="decorativos">Decorativos</option>
                  <option value="especiais">Projetos Especiais</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categorias de Produtos */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {categorias.map((categoria) => (
              <div key={categoria.id} className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
                <div className="h-48 bg-gray-300 flex items-center justify-center">
                  <span className="text-gray-500">Imagem da Categoria</span>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{categoria.nome}</h3>
                  <p className="text-gray-600 mb-4">
                    {categoria.descricao}
                  </p>
                  <Link 
                    href={`/produtos/${categoria.id}`} 
                    className="text-blue-600 hover:text-blue-800 font-medium flex items-center"
                  >
                    Ver produtos <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Produtos em Destaque */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Produtos em Destaque</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Conheça alguns dos nossos produtos mais populares e suas aplicações.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Produto 1 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-40 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Imagem do Produto</span>
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-1">Box de Vidro Temperado</h3>
                <p className="text-sm text-gray-600 mb-2">
                  Para banheiros, com diversos acabamentos e opções de personalização.
                </p>
                <Link 
                  href="/produtos/temperados/box" 
                  className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                >
                  Detalhes
                </Link>
              </div>
            </div>
            
            {/* Produto 2 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-40 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Imagem do Produto</span>
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-1">Guarda-corpo em Vidro</h3>
                <p className="text-sm text-gray-600 mb-2">
                  Segurança e elegância para escadas, sacadas e mezaninos.
                </p>
                <Link 
                  href="/produtos/temperados/guarda-corpo" 
                  className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                >
                  Detalhes
                </Link>
              </div>
            </div>
            
            {/* Produto 3 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-40 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Imagem do Produto</span>
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-1">Vidro Laminado Acústico</h3>
                <p className="text-sm text-gray-600 mb-2">
                  Isolamento acústico e proteção UV para ambientes mais confortáveis.
                </p>
                <Link 
                  href="/produtos/laminados/acustico" 
                  className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                >
                  Detalhes
                </Link>
              </div>
            </div>
            
            {/* Produto 4 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-40 bg-gray-300 flex items-center justify-center">
                <span className="text-gray-500">Imagem do Produto</span>
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-1">Espelho Decorativo</h3>
                <p className="text-sm text-gray-600 mb-2">
                  Espelhos lapidados e bisotados para decoração de ambientes.
                </p>
                <Link 
                  href="/produtos/decorativos/espelhos" 
                  className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                >
                  Detalhes
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Informações Técnicas */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Informações Técnicas</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Conheça as especificações técnicas e características dos nossos produtos.
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipo de Vidro</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Espessuras</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Características</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aplicações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Vidro Temperado</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">6mm, 8mm, 10mm, 12mm</td>
                    <td className="px-6 py-4 text-sm text-gray-500">Resistência mecânica 5x maior que o vidro comum</td>
                    <td className="px-6 py-4 text-sm text-gray-500">Portas, janelas, divisórias, guarda-corpos</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Vidro Laminado</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">6mm, 8mm, 10mm, 12mm</td>
                    <td className="px-6 py-4 text-sm text-gray-500">Segurança, proteção UV, isolamento acústico</td>
                    <td className="px-6 py-4 text-sm text-gray-500">Fachadas, coberturas, guarda-corpos</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Vidro Comum</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">3mm, 4mm, 5mm, 6mm</td>
                    <td className="px-6 py-4 text-sm text-gray-500">Transparência, custo-benefício</td>
                    <td className="px-6 py-4 text-sm text-gray-500">Molduras, tampos, prateleiras</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Vidro Jateado</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">4mm, 6mm, 8mm</td>
                    <td className="px-6 py-4 text-sm text-gray-500">Translúcido, privacidade, efeito fosco</td>
                    <td className="px-6 py-4 text-sm text-gray-500">Divisórias, portas, elementos decorativos</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* CTA - Orçamento */}
      <section className="py-16 bg-blue-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Precisa de um produto personalizado?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Entre em contato conosco e solicite um orçamento sem compromisso. Nossa equipe está pronta para desenvolver a solução ideal para seu projeto.
          </p>
          <Link 
            href="/orcamentos" 
            className="bg-white text-blue-700 hover:bg-gray-100 px-8 py-4 rounded-md font-bold text-lg inline-block"
          >
            Solicitar Orçamento
          </Link>
        </div>
      </section>
    </div>
  )
}
